Acesse a pasta

%appdata%\..\Local\Arduino15\packages\digistump\hardware\avr\1.6.7\libraries\DigisparkKeyboard

Troque no nome dos arquivos DigiKeyboard.h e scancode-ascii-table.h existentes

Copie os novos DigiKeyboard.h e scancode-ascii-table.h na pasta %appdata%\..\Local\Arduino15\packages\digistump\hardware\avr\1.6.7\libraries\DigisparkKeyboard

O metodo de adicionar como Zip nao funciona


Done!