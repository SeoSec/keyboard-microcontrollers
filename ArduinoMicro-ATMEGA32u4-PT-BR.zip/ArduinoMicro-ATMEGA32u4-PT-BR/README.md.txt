Acesse a pasta

C:\Program Files\Arduino\libraries\Keyboard\src

Troque no nome dos arquivos Keyboard.cpp e Keyboard.h existentes

Copie os novos Keyboard.cpp e Keyboard.h na pasta C:\Program Files\Arduino\libraries\Keyboard\src


Ou adicione a biblioteca como Zip


Done!

